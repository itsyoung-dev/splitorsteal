const { ContextMenuCommandBuilder, ApplicationCommandType } = require("discord.js");

module.exports = {
  deleted: true,
  data: new ContextMenuCommandBuilder()
    .setName("exampleCTM")
    .setType(ApplicationCommandType.User)
  ,
  devOnly: true,
  testMode: true,
  userPermissions: [],
  botPermissions: [],

  run: async (client, interaction) => {
    
  }
};